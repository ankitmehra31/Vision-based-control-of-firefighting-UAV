#!/usr/bin/env python3
import cv2
#import roslib
import sys
from std_msgs.msg import String
import rospy, cv_bridge
from sensor_msgs.msg import Image
import ultralytics
from ultralytics import YOLO
import time
import rospy
from custom_msg_python.msg import custom

model = YOLO('/home/firefighter/catkin_ws/src/custom_msg_python/src/best_2.pt')
prev_frame_time=0
new_frame_time=0

global fire_detected ,cv_image1
fire_detected = False
bridge = cv_bridge.CvBridge()

def image_callback(msg):  
  cv2_img = bridge.imgmsg_to_cv2(msg, "bgr8")
  image = bridge.imgmsg_to_cv2(msg, desired_encoding = 'bgr8')
  global fire_detected
  pub=rospy.Publisher("custom_message",custom,queue_size=10)
  rospy.init_node("custom_publisher",anonymous=True)
  rate=rospy.Rate(6)
  msg=custom()
  print("namaste")

  
  while not rospy.is_shutdown():
      # Read frame from camera
      ret, frame = cap.read()
      
      # Perform object detection
      results = model.predict(frame)
      
      detected = False  # Initialize detection flag
      
      for result in results:
          if len(result.boxes) > 0:  # Check if any boxes are detected
              detected = True  # Set detected to True
              for bbox in result.boxes.xyxy:
                  x1, y1, x2, y2 = bbox[0].item(), bbox[1].item(), bbox[2].item(), bbox[3].item()
                  # Draw bounding box around detected object (fire)
                  #color = (0, 255, 0)  # Green color
                  #thickness = 2
                  #cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), color, thickness)
                  centroid = [(x1 + x2) / 2, (y1 + y2) / 2]
                  msg.coordinates=centroid
                  break  # Only consider the first detected box and centroid
          else:
              msg.coordinates=[384/2,384/2]
      if detected:
          fire_detected = True
          print("Fire Detected")
          #print("Centroid:", centroid)
          print("True")
          cmd = "1"
          # break  # Stop the code execution if fire is detected
      if not fire_detected:
          print("No fire detected")
          print("False")
          #msg.coordinates=[0,0]
          cmd = "0"
          # break
      
      # Display frame with bounding boxes and centroid
      #cv2.imshow("Fire Detection", frame)

      # Check for 'q' key press to exit the loop
      # if cv2.waitKey(1) & 0xFF == ord('q'):
      #     break

      #while not rospy.isshutdown():
      rospy.loginfo(msg)
      pub.publish(msg)
      rate.sleep()
   
def callback():
    print("hi")

def main():
    rospy.init_node("img_feature", anonymous=True)
    image_topic = "/usb_cam/image_raw"
    image_sub = rospy.Subscriber(image_topic, Image, image_callback)
    rospy.spin()
if __name__=='__main__':
    main()
  #img_feature_pub = rospy.Publisher('/features', CamInfo, queue_size = 10)
  

