#!/home/firefighter/myenv/bin/python3

import cv2
import ultralytics
from ultralytics import YOLO
import sys
import time
# import rospy
from custom_msg_python.msg import custom
# from cv_bridge import CvBridge
import rospy, cv_bridge
from sensor_msgs.msg import Image

model = YOLO('/home/firefighter/catkin_ws/src/custom_msg_python/src/best_2.pt')
prev_frame_time=0
new_frame_time=0

global fire_detected ,cv_image1
fire_detected = False
# bridge = CvBridge()


def image_callback(data):
    bridge = cv_bridge.CvBridge()
    # bridge = CvBridge()
    cv_image1 = bridge.imgmsg_to_cv2(data,"bgr8")
    print("hio")    
    results = model.predict(cv_image1)

    msg=custom()

    
    if len(result.boxes) > 0:  # Check if any boxes are detected
        detected = True  # Set detected to True
        print("Fire Detected")

        x1, y1, x2, y2 = bbox[0].item(), bbox[1].item(), bbox[2].item(), bbox[3].item()
        centroid = [(x1 + x2) / 2, (y1 + y2) / 2]
        msg.coordinates=centroid

    else:
        msg.coordinates=[384/2,384/2]
        print("No fire detected")
    
    
    rospy.loginfo(msg)
    img_feature_pub.publish(msg)
    rate.sleep()
    # rospy.spin()

if __name__=="__main__":

    rospy.init_node("img_feature", anonymous=True)
    image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback)
    img_feature_pub = rospy.Publisher('custom_message', custom, queue_size = 10)
    rate = rospy.Rate(10)
    rospy.spin()





# model = load_model('/home/xavier/red_colored.h5')
# #model = load_model('/home/xavier/net2508small.h5')
# #tf.debugging.set_log_device_placement(True)
# #result = cv2.VideoWriter("encode.avi", cv2.VideoWriter_fourcc(*'MJPG'), 10, (640,160))
# def image_callback(msg):
#   bridge = cv_bridge.CvBridge()  
#   image = bridge.imgmsg_to_cv2(msg, desired_encoding = 'bgr8')
#  # image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#   image = np.float32(image[320:480,0:640])/255
#   image = image.reshape(1,160,640,3)
#   out = model.predict(image)
#   out = out.reshape(160,640)*255
#   out = out[10:150,0:640]
#   out = out.astype(np.uint8)
# #  result.write(out)
#   cnts, hierarchy = cv2.findContours(out.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
#   center = None
   
#   if len(cnts) > 0:
#     c = max(cnts, key=cv2.contourArea)
#     x, y, w, h = cv2.boundingRect(c)
#     print(x,y,w,h, "(x, y) and (width, height)")
#     M = cv2.moments(c)
#     out = cv2.rectangle(out, (x, y), (x+w, y+h), (255,255,255), 2)
 
# #  cv2.imshow("The image is", out*255)


#   caminfo = CamInfo()
#   caminfo.x_pos = x
#   caminfo.y_pos = y
#   caminfo.width = w
#   caminfo.height = h
 
#   img_feature_pub.publish(caminfo)
#   rate.sleep()

#   print(x,y,w,h, 'x_pos', 'y_pos', 'width', 'height')

# if __name__=='__main__':
#   rospy.init_node("img_feature", anonymous=True)
#   image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback)
#   img_feature_pub = rospy.Publisher('/features', CamInfo, queue_size = 10)
#   rate = rospy.Rate(10)
#   rospy.spin()